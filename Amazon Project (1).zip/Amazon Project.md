```python
import pandas as pd
```


```python
a= pd.read_csv("Amazon_Sale_Report.csv")
a
```

    C:\Users\Sooraj\AppData\Local\Temp\ipykernel_33348\1430323958.py:1: DtypeWarning: Columns (23) have mixed types. Specify dtype option on import or set low_memory=False.
      a= pd.read_csv("Amazon_Sale_Report.csv")
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Order ID</th>
      <th>Date</th>
      <th>Status</th>
      <th>Fulfilment</th>
      <th>Sales Channel</th>
      <th>ship-service-level</th>
      <th>Style</th>
      <th>SKU</th>
      <th>Category</th>
      <th>...</th>
      <th>currency</th>
      <th>Amount</th>
      <th>ship-city</th>
      <th>ship-state</th>
      <th>ship-postal-code</th>
      <th>ship-country</th>
      <th>promotion-ids</th>
      <th>B2B</th>
      <th>fulfilled-by</th>
      <th>Unnamed: 22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>405-8078784-5731545</td>
      <td>04-30-22</td>
      <td>Cancelled</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>SET389</td>
      <td>SET389-KR-NP-S</td>
      <td>Set</td>
      <td>...</td>
      <td>INR</td>
      <td>647.62</td>
      <td>MUMBAI</td>
      <td>MAHARASHTRA</td>
      <td>400081.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>Easy Ship</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>171-9198151-1101146</td>
      <td>04-30-22</td>
      <td>Shipped - Delivered to Buyer</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>JNE3781</td>
      <td>JNE3781-KR-XXXL</td>
      <td>kurta</td>
      <td>...</td>
      <td>INR</td>
      <td>406.00</td>
      <td>BENGALURU</td>
      <td>KARNATAKA</td>
      <td>560085.0</td>
      <td>IN</td>
      <td>Amazon PLCC Free-Financing Universal Merchant ...</td>
      <td>False</td>
      <td>Easy Ship</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>404-0687676-7273146</td>
      <td>04-30-22</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3371</td>
      <td>JNE3371-KR-XL</td>
      <td>kurta</td>
      <td>...</td>
      <td>INR</td>
      <td>329.00</td>
      <td>NAVI MUMBAI</td>
      <td>MAHARASHTRA</td>
      <td>410210.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>True</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>403-9615377-8133951</td>
      <td>04-30-22</td>
      <td>Cancelled</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>J0341</td>
      <td>J0341-DR-L</td>
      <td>Western Dress</td>
      <td>...</td>
      <td>INR</td>
      <td>753.33</td>
      <td>PUDUCHERRY</td>
      <td>PUDUCHERRY</td>
      <td>605008.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>Easy Ship</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>407-1069790-7240320</td>
      <td>04-30-22</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3671</td>
      <td>JNE3671-TU-XXXL</td>
      <td>Top</td>
      <td>...</td>
      <td>INR</td>
      <td>574.00</td>
      <td>CHENNAI</td>
      <td>TAMIL NADU</td>
      <td>600073.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>128970</th>
      <td>128970</td>
      <td>406-6001380-7673107</td>
      <td>05-31-22</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3697</td>
      <td>JNE3697-KR-XL</td>
      <td>kurta</td>
      <td>...</td>
      <td>INR</td>
      <td>517.00</td>
      <td>HYDERABAD</td>
      <td>TELANGANA</td>
      <td>500013.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>128971</th>
      <td>128971</td>
      <td>402-9551604-7544318</td>
      <td>05-31-22</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>SET401</td>
      <td>SET401-KR-NP-M</td>
      <td>Set</td>
      <td>...</td>
      <td>INR</td>
      <td>999.00</td>
      <td>GURUGRAM</td>
      <td>HARYANA</td>
      <td>122004.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>128972</th>
      <td>128972</td>
      <td>407-9547469-3152358</td>
      <td>05-31-22</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0157</td>
      <td>J0157-DR-XXL</td>
      <td>Western Dress</td>
      <td>...</td>
      <td>INR</td>
      <td>690.00</td>
      <td>HYDERABAD</td>
      <td>TELANGANA</td>
      <td>500049.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>128973</th>
      <td>128973</td>
      <td>402-6184140-0545956</td>
      <td>05-31-22</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0012</td>
      <td>J0012-SKD-XS</td>
      <td>Set</td>
      <td>...</td>
      <td>INR</td>
      <td>1199.00</td>
      <td>Halol</td>
      <td>Gujarat</td>
      <td>389350.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>128974</th>
      <td>128974</td>
      <td>408-7436540-8728312</td>
      <td>05-31-22</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0003</td>
      <td>J0003-SET-S</td>
      <td>Set</td>
      <td>...</td>
      <td>INR</td>
      <td>696.00</td>
      <td>Raipur</td>
      <td>CHHATTISGARH</td>
      <td>492014.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>128975 rows × 24 columns</p>
</div>




```python
a.isnull().sum()
```




    index                     0
    Order ID                  0
    Date                      0
    Status                    0
    Fulfilment                0
    Sales Channel             0
    ship-service-level        0
    Style                     0
    SKU                       0
    Category                  0
    Size                      0
    ASIN                      0
    Courier Status         6872
    Qty                       0
    currency               7795
     Amount                7795
    ship-city                33
    ship-state               33
    ship-postal-code         33
    ship-country             33
    promotion-ids         49153
    B2B                       0
    fulfilled-by          89698
    Unnamed: 22           49050
    dtype: int64




```python
a.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 128975 entries, 0 to 128974
    Data columns (total 20 columns):
     #   Column              Non-Null Count   Dtype  
    ---  ------              --------------   -----  
     0   index               128975 non-null  int64  
     1   Order ID            128975 non-null  object 
     2   Date                128975 non-null  object 
     3   Status              128975 non-null  object 
     4   Fulfilment          128975 non-null  object 
     5   ship-service-level  128975 non-null  object 
     6   Style               128975 non-null  object 
     7   SKU                 128975 non-null  object 
     8   Category            128975 non-null  object 
     9   Size                128975 non-null  object 
     10  ASIN                128975 non-null  object 
     11  Courier Status      122103 non-null  object 
     12  Qty                 128975 non-null  int64  
     13   Amount             121180 non-null  object 
     14  ship-city           128942 non-null  object 
     15  ship-state          128942 non-null  object 
     16  ship-postal-code    128942 non-null  float64
     17  B2B                 128975 non-null  bool   
     18  fulfilled-by        39277 non-null   object 
     19  Unnamed: 22         79925 non-null   object 
    dtypes: bool(1), float64(1), int64(2), object(16)
    memory usage: 18.8+ MB
    


```python
Total_orders= a["Order ID"].nunique()
print("Total Orders:",Total_orders)
```

    Total Orders: 120378
    


```python
Total_quantity=a["Qty"].sum()
print("Total Quantity:", Total_quantity)
```

    Total Quantity: 116649
    


```python
Total_Amount=a["Amount"].sum()
print("Total Amount:",Total_Amount)
```

    Total Amount: 78592678.29999998
    


```python
Customer_Sales=a.groupby("Order ID").agg({"Qty":"sum",}).reset_index()
print(Customer_Sales)
```

                       Order ID  Qty
    0       171-0000547-8192359    1
    1       171-0000902-4490745    1
    2       171-0001409-6228339    1
    3       171-0003082-5110755    1
    4       171-0003738-2052324    1
    ...                     ...  ...
    120373  S02-9578181-3610412    1
    120374  S02-9599483-2736812    1
    120375  S02-9649067-3246849    1
    120376  S02-9736323-0094708    1
    120377  S02-9878098-5959538    1
    
    [120378 rows x 2 columns]
    


```python
total_amount = a['Amount'].sum()
print("Total Gross Amount:", total_amount)

```

    Total Gross Amount: 78592678.29999998
    


```python
if 'Unnamed: 22' in a.columns:
    a.drop(columns=['Unnamed: 22'], inplace=True)

print(a.columns.tolist())

print(a.isnull().sum())

```

    ['index', 'Order ID', 'Date', 'Status', 'Fulfilment', 'Sales Channel ', 'ship-service-level', 'Style', 'SKU', 'Category', 'Size', 'ASIN', 'Courier Status', 'Qty', 'currency', 'Amount', 'ship-city', 'ship-state', 'ship-postal-code', 'ship-country', 'promotion-ids', 'B2B', 'fulfilled-by']
    index                     0
    Order ID                  0
    Date                      0
    Status                    0
    Fulfilment                0
    Sales Channel             0
    ship-service-level        0
    Style                     0
    SKU                       0
    Category                  0
    Size                      0
    ASIN                      0
    Courier Status         6872
    Qty                       0
    currency               7795
    Amount                 7795
    ship-city                33
    ship-state               33
    ship-postal-code         33
    ship-country             33
    promotion-ids         49153
    B2B                       0
    fulfilled-by          89698
    dtype: int64
    


```python
fulfilment_summary = a['Fulfilment'].value_counts()
print("Orders by Fulfilment Type:", fulfilment_summary)

```

    Orders by Fulfilment Type: Fulfilment
    Amazon      89698
    Merchant    39277
    Name: count, dtype: int64
    


```python
status_summary = a['Status'].value_counts()
print("Order Status Breakdown:", status_summary)

```

    Order Status Breakdown: Status
    Shipped                          77804
    Shipped - Delivered to Buyer     28769
    Cancelled                        18332
    Shipped - Returned to Seller      1953
    Shipped - Picked Up                973
    Pending                            658
    Pending - Waiting for Pick Up      281
    Shipped - Returning to Seller      145
    Shipped - Out for Delivery          35
    Shipped - Rejected by Buyer         11
    Shipping                             8
    Shipped - Lost in Transit            5
    Shipped - Damaged                    1
    Name: count, dtype: int64
    


```python
courier_status_summary = a['Courier Status'].value_counts()
print("Courier Status Breakdown:", courier_status_summary)

```

    Courier Status Breakdown: Courier Status
    Shipped      109487
    Unshipped      6681
    Cancelled      5935
    Name: count, dtype: int64
    


```python
top_states = a.groupby('ship-state')['Amount'].sum().sort_values(ascending=False).head()
top_cities = a.groupby('ship-city')['Amount'].sum().sort_values(ascending=False).head()

print("Top States by Sales:", top_states)
print("Top Cities by Sales:", top_cities)

```

    Top States by Sales: ship-state
    MAHARASHTRA      13335534.14
    KARNATAKA        10481114.37
    TELANGANA         6916615.65
    UTTAR PRADESH     6816642.08
    TAMIL NADU        6515650.11
    Name: Amount, dtype: float64
    Top Cities by Sales: ship-city
    BENGALURU    6849664.99
    HYDERABAD    4946032.82
    MUMBAI       3704461.80
    NEW DELHI    3613874.78
    CHENNAI      3098745.74
    Name: Amount, dtype: float64
    


```python
top_styles = a.groupby('Style')['Amount'].sum().sort_values(ascending=False).head()
top_categories = a.groupby('Category')['Amount'].sum().sort_values(ascending=False).head()

print("Top Styles by Sales:", top_styles)
print("Top Categories by Sales:", top_categories)

```

    Top Styles by Sales: Style
    JNE3797    2933482.00
    J0230      1944948.48
    SET268     1303923.56
    J0341      1275322.87
    J0003       981973.75
    Name: Amount, dtype: float64
    Top Categories by Sales: Category
    Set              39204124.03
    kurta            21299546.70
    Western Dress    11216072.69
    Top               5347792.30
    Ethnic Dress       791217.66
    Name: Amount, dtype: float64
    


```python
a['Date'] = pd.to_datetime(a['Date'])
a

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Order ID</th>
      <th>Date</th>
      <th>Status</th>
      <th>Fulfilment</th>
      <th>Sales Channel</th>
      <th>ship-service-level</th>
      <th>Style</th>
      <th>SKU</th>
      <th>Category</th>
      <th>...</th>
      <th>Qty</th>
      <th>currency</th>
      <th>Amount</th>
      <th>ship-city</th>
      <th>ship-state</th>
      <th>ship-postal-code</th>
      <th>ship-country</th>
      <th>promotion-ids</th>
      <th>B2B</th>
      <th>fulfilled-by</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>405-8078784-5731545</td>
      <td>2022-04-30</td>
      <td>Cancelled</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>SET389</td>
      <td>SET389-KR-NP-S</td>
      <td>Set</td>
      <td>...</td>
      <td>0</td>
      <td>INR</td>
      <td>647.62</td>
      <td>MUMBAI</td>
      <td>MAHARASHTRA</td>
      <td>400081.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>Easy Ship</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>171-9198151-1101146</td>
      <td>2022-04-30</td>
      <td>Shipped - Delivered to Buyer</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>JNE3781</td>
      <td>JNE3781-KR-XXXL</td>
      <td>kurta</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>406.00</td>
      <td>BENGALURU</td>
      <td>KARNATAKA</td>
      <td>560085.0</td>
      <td>IN</td>
      <td>Amazon PLCC Free-Financing Universal Merchant ...</td>
      <td>False</td>
      <td>Easy Ship</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>404-0687676-7273146</td>
      <td>2022-04-30</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3371</td>
      <td>JNE3371-KR-XL</td>
      <td>kurta</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>329.00</td>
      <td>NAVI MUMBAI</td>
      <td>MAHARASHTRA</td>
      <td>410210.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>True</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>403-9615377-8133951</td>
      <td>2022-04-30</td>
      <td>Cancelled</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>J0341</td>
      <td>J0341-DR-L</td>
      <td>Western Dress</td>
      <td>...</td>
      <td>0</td>
      <td>INR</td>
      <td>753.33</td>
      <td>PUDUCHERRY</td>
      <td>PUDUCHERRY</td>
      <td>605008.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>Easy Ship</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>407-1069790-7240320</td>
      <td>2022-04-30</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3671</td>
      <td>JNE3671-TU-XXXL</td>
      <td>Top</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>574.00</td>
      <td>CHENNAI</td>
      <td>TAMIL NADU</td>
      <td>600073.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>128970</th>
      <td>128970</td>
      <td>406-6001380-7673107</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3697</td>
      <td>JNE3697-KR-XL</td>
      <td>kurta</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>517.00</td>
      <td>HYDERABAD</td>
      <td>TELANGANA</td>
      <td>500013.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>128971</th>
      <td>128971</td>
      <td>402-9551604-7544318</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>SET401</td>
      <td>SET401-KR-NP-M</td>
      <td>Set</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>999.00</td>
      <td>GURUGRAM</td>
      <td>HARYANA</td>
      <td>122004.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>128972</th>
      <td>128972</td>
      <td>407-9547469-3152358</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0157</td>
      <td>J0157-DR-XXL</td>
      <td>Western Dress</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>690.00</td>
      <td>HYDERABAD</td>
      <td>TELANGANA</td>
      <td>500049.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>128973</th>
      <td>128973</td>
      <td>402-6184140-0545956</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0012</td>
      <td>J0012-SKD-XS</td>
      <td>Set</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>1199.00</td>
      <td>Halol</td>
      <td>Gujarat</td>
      <td>389350.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>128974</th>
      <td>128974</td>
      <td>408-7436540-8728312</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0003</td>
      <td>J0003-SET-S</td>
      <td>Set</td>
      <td>...</td>
      <td>1</td>
      <td>INR</td>
      <td>696.00</td>
      <td>Raipur</td>
      <td>CHHATTISGARH</td>
      <td>492014.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>128975 rows × 23 columns</p>
</div>




```python
a['Year-Month'] =a['Date'].dt.to_period('M')
a

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>Order ID</th>
      <th>Date</th>
      <th>Status</th>
      <th>Fulfilment</th>
      <th>Sales Channel</th>
      <th>ship-service-level</th>
      <th>Style</th>
      <th>SKU</th>
      <th>Category</th>
      <th>...</th>
      <th>Amount</th>
      <th>ship-city</th>
      <th>ship-state</th>
      <th>ship-postal-code</th>
      <th>ship-country</th>
      <th>promotion-ids</th>
      <th>B2B</th>
      <th>fulfilled-by</th>
      <th>Year-Month</th>
      <th>Month-Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>405-8078784-5731545</td>
      <td>2022-04-30</td>
      <td>Cancelled</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>SET389</td>
      <td>SET389-KR-NP-S</td>
      <td>Set</td>
      <td>...</td>
      <td>647.62</td>
      <td>MUMBAI</td>
      <td>MAHARASHTRA</td>
      <td>400081.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>Easy Ship</td>
      <td>2022-04</td>
      <td>2022-04</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>171-9198151-1101146</td>
      <td>2022-04-30</td>
      <td>Shipped - Delivered to Buyer</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>JNE3781</td>
      <td>JNE3781-KR-XXXL</td>
      <td>kurta</td>
      <td>...</td>
      <td>406.00</td>
      <td>BENGALURU</td>
      <td>KARNATAKA</td>
      <td>560085.0</td>
      <td>IN</td>
      <td>Amazon PLCC Free-Financing Universal Merchant ...</td>
      <td>False</td>
      <td>Easy Ship</td>
      <td>2022-04</td>
      <td>2022-04</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>404-0687676-7273146</td>
      <td>2022-04-30</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3371</td>
      <td>JNE3371-KR-XL</td>
      <td>kurta</td>
      <td>...</td>
      <td>329.00</td>
      <td>NAVI MUMBAI</td>
      <td>MAHARASHTRA</td>
      <td>410210.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>True</td>
      <td>NaN</td>
      <td>2022-04</td>
      <td>2022-04</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>403-9615377-8133951</td>
      <td>2022-04-30</td>
      <td>Cancelled</td>
      <td>Merchant</td>
      <td>Amazon.in</td>
      <td>Standard</td>
      <td>J0341</td>
      <td>J0341-DR-L</td>
      <td>Western Dress</td>
      <td>...</td>
      <td>753.33</td>
      <td>PUDUCHERRY</td>
      <td>PUDUCHERRY</td>
      <td>605008.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>Easy Ship</td>
      <td>2022-04</td>
      <td>2022-04</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>407-1069790-7240320</td>
      <td>2022-04-30</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3671</td>
      <td>JNE3671-TU-XXXL</td>
      <td>Top</td>
      <td>...</td>
      <td>574.00</td>
      <td>CHENNAI</td>
      <td>TAMIL NADU</td>
      <td>600073.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
      <td>2022-04</td>
      <td>2022-04</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>128970</th>
      <td>128970</td>
      <td>406-6001380-7673107</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>JNE3697</td>
      <td>JNE3697-KR-XL</td>
      <td>kurta</td>
      <td>...</td>
      <td>517.00</td>
      <td>HYDERABAD</td>
      <td>TELANGANA</td>
      <td>500013.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
      <td>2022-05</td>
      <td>2022-05</td>
    </tr>
    <tr>
      <th>128971</th>
      <td>128971</td>
      <td>402-9551604-7544318</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>SET401</td>
      <td>SET401-KR-NP-M</td>
      <td>Set</td>
      <td>...</td>
      <td>999.00</td>
      <td>GURUGRAM</td>
      <td>HARYANA</td>
      <td>122004.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
      <td>2022-05</td>
      <td>2022-05</td>
    </tr>
    <tr>
      <th>128972</th>
      <td>128972</td>
      <td>407-9547469-3152358</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0157</td>
      <td>J0157-DR-XXL</td>
      <td>Western Dress</td>
      <td>...</td>
      <td>690.00</td>
      <td>HYDERABAD</td>
      <td>TELANGANA</td>
      <td>500049.0</td>
      <td>IN</td>
      <td>NaN</td>
      <td>False</td>
      <td>NaN</td>
      <td>2022-05</td>
      <td>2022-05</td>
    </tr>
    <tr>
      <th>128973</th>
      <td>128973</td>
      <td>402-6184140-0545956</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0012</td>
      <td>J0012-SKD-XS</td>
      <td>Set</td>
      <td>...</td>
      <td>1199.00</td>
      <td>Halol</td>
      <td>Gujarat</td>
      <td>389350.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
      <td>2022-05</td>
      <td>2022-05</td>
    </tr>
    <tr>
      <th>128974</th>
      <td>128974</td>
      <td>408-7436540-8728312</td>
      <td>2022-05-31</td>
      <td>Shipped</td>
      <td>Amazon</td>
      <td>Amazon.in</td>
      <td>Expedited</td>
      <td>J0003</td>
      <td>J0003-SET-S</td>
      <td>Set</td>
      <td>...</td>
      <td>696.00</td>
      <td>Raipur</td>
      <td>CHHATTISGARH</td>
      <td>492014.0</td>
      <td>IN</td>
      <td>IN Core Free Shipping 2015/04/08 23-48-5-108</td>
      <td>False</td>
      <td>NaN</td>
      <td>2022-05</td>
      <td>2022-05</td>
    </tr>
  </tbody>
</table>
<p>128975 rows × 25 columns</p>
</div>




```python
monthly_sales =a.groupby('Year-Month')['Amount'].sum().reset_index()
monthly_sales['Year-Month'] = monthly_sales['Year-Month'].astype(str)

print(monthly_sales.head())

```

      Year-Month       Amount
    0    2022-03    101683.85
    1    2022-04  28838708.32
    2    2022-05  26226476.75
    3    2022-06  23425809.38
    


```python
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 5))
plt.plot(monthly_sales['Year-Month'], monthly_sales['Amount'], marker='o', color='teal')
plt.title('Monthly Sales Trend')
plt.xlabel('Month')
plt.ylabel('Total Amount')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

```


    
![png](output_18_0.png)
    



```python
print(a['Status'].unique())

cancelled_orders = a[a['Status'].str.lower().isin(['cancelled', 'returned'])]

print("Total Cancelled/Returned Orders:", cancelled_orders['Order ID'].nunique())

print("Total Value Lost:", cancelled_orders['Amount'].sum())

```

    ['Cancelled' 'Shipped - Delivered to Buyer' 'Shipped'
     'Shipped - Returned to Seller' 'Shipped - Rejected by Buyer'
     'Shipped - Lost in Transit' 'Shipped - Out for Delivery'
     'Shipped - Returning to Seller' 'Shipped - Picked Up' 'Pending'
     'Pending - Waiting for Pick Up' 'Shipped - Damaged' 'Shipping']
    Total Cancelled/Returned Orders: 17185
    Total Value Lost: 6919284.3
    


```python
sku_sales = a.groupby('SKU').agg({
    'Qty': 'sum',
    'Amount': 'sum'
}).sort_values(by='Amount', ascending=False).reset_index()

print(sku_sales.head())

```

                SKU  Qty     Amount
    0   J0230-SKD-M  468  527699.20
    1  JNE3797-KR-L  661  524581.77
    2   J0230-SKD-S  421  479937.14
    3  JNE3797-KR-M  561  454290.16
    4  JNE3797-KR-S  503  407302.57
    


```python
top_styles = a.groupby('Style')['Amount'].sum().sort_values(ascending=False).head(5)
top_styles.plot(kind='bar', color='salmon', title='Top 5 Styles by Sales')
plt.ylabel('Amount')
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_21_0.png)
    



```python
a['Fulfilment'].value_counts().plot(kind='pie', autopct='%1.1f%%', startangle=90)
plt.title('Fulfilment Type Distribution')
plt.ylabel('')
plt.show()

```


    
![png](output_22_0.png)
    



```python
state_sales = a.groupby('ship-state')['Amount'].sum().sort_values(ascending=True).head(10)
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 6))
state_sales.plot(kind='barh', color='skyblue')
plt.title('Total 10 Sales by State')
plt.xlabel('Total Sales Amount')
plt.ylabel('Shipping State')
plt.tight_layout()
plt.show()

```


    
![png](output_23_0.png)
    



```python

```


```python

```
